import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("68065abf-c497-4d65-9f85-a27a3dd54897")
public class OptionRéservation {
    @objid ("ee4398fb-e1ff-420e-be7b-2c3444f56b59")
    protected int Id;

    @objid ("a4f19e9b-4eb5-40fe-a01b-254262c24142")
    public float prix_Unitaire;

    @objid ("68f006f8-fbe9-48bb-a871-416c6eaf4761")
    public String Type;

}
