import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("33187267-6a73-4ad6-9e27-2f587cec97f8")
public class Réservation {
    @objid ("d5082a8e-189e-48e7-b6aa-630964b2d1d4")
    protected int Numéro_Reser;

    @objid ("e2f541f7-c619-4c2b-afd0-ac16b1d1464d")
    public Date Date_Début;

    @objid ("220415fe-e18c-49db-95f7-f61a43f0a22c")
    public Date Date_Fin;

    @objid ("0b24d7e0-38d8-48ee-a26c-6b30f2674561")
    public float prix;

    @objid ("34e8d32b-eb01-4639-85b1-d4ad80f87865")
    public String Statut;

}
