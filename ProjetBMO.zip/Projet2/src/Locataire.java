import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("42a84a7e-5c6f-4c17-9a34-18f11d665f7d")
public class Locataire extends User {
}
