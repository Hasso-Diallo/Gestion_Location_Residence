import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a7f9d3be-823c-47ec-a9d8-8e2c21c44f95")
public class Communication {
    @objid ("1aab0f68-f258-471d-9337-201438d94bb3")
    protected int Id_Comm;

    @objid ("4c10c4ea-300a-4882-9b34-35c253b51045")
    public String Contenu;

    @objid ("7c86f37f-bb37-40c6-92ce-28c022871848")
    public Date Date_Envoie;

}
