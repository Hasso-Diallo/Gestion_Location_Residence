import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8ecf3fae-bcea-4495-bfbe-0ad1ce6897dd")
public class Tarif {
    @objid ("956a5d3b-4080-4b80-927d-e2102503005e")
    protected int Id;

    @objid ("610d6c6c-90df-43c9-a52d-ac5c7e81b536")
    public float prix_Unitaire;

    @objid ("935fe826-e150-4ec0-b3ce-a633009925bb")
    public Date Date_Fin;

    @objid ("ff23fffb-2aae-426e-96cb-ae05b46df758")
    public Date Date_Début;

    @objid ("a016856e-1cd0-4b8d-9c3c-d2389e6cb556")
    public String Titre;

}
