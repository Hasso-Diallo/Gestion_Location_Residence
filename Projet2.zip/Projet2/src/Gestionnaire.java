import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b85dde6f-4019-42b8-9b48-554a5ab437e6")
public class Gestionnaire extends User {
}
