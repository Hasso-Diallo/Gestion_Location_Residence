import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("de878628-1727-4104-83e0-0b06ed6a4b8e")
public class User {
    @objid ("cccbffbc-5b3c-49f0-9a77-95d5552bcaae")
    public String Nom;

    @objid ("a31d6d5e-92ce-49b5-9375-fb97809fae82")
    public String Prenom;

    @objid ("b78d6c71-067c-494a-a0f8-51bbbf3406b9")
    public String Email;

    @objid ("ddaaa921-a243-41cf-9291-22387adee4d4")
    public int Téléphone;

    @objid ("a491dcfd-0784-44f1-9937-e247cd4b4d71")
    private String password;

}
