import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4b79eaf1-6c86-4c32-bfe2-57fcd821ed27")
public class Paiement {
    @objid ("336436d0-d0e6-40b9-ac14-816f9340457f")
    protected String Code;

    @objid ("e4c942b3-2bb0-4b19-945a-bdf065a708a0")
    public float Montant;

    @objid ("f6156f63-8d64-428d-b4bb-78450fc3989b")
    public String Moyen_Paiement;

    @objid ("8ef49a53-6e69-4a1b-97cb-981e29a5056e")
    public String Mode;

}
