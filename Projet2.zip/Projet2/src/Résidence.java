import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8995053d-6798-41f3-8a51-e5d05338b2f2")
public class Résidence {
    @objid ("485106cf-f1e2-49a4-8427-3d7a6d2c3a29")
    protected int id;

    @objid ("5a172b26-2825-490b-a377-3d10cbb7071e")
    public String Nom;

    @objid ("cacf1b2c-3d96-4617-b538-fe337c39b99c")
    public String adresse;

    @objid ("618d6728-7e7c-4416-8ae7-d6d22b02d1f2")
    public String description;

}
