import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("734b47b6-0d5b-4eea-a7ff-b84cbbac5554")
public class ElémentRésidence {
    @objid ("93d39a9d-3319-42e5-8855-1986aec0a6f7")
    protected int Identifiant;

    @objid ("8f5e5c4e-2151-4036-ad75-be5fedcbc5ca")
    public String Nom;

    @objid ("7e9a594e-506b-4ecc-a541-5d1a0c3f5958")
    public String Description;

    @objid ("bc8d4352-9fe6-4b96-9978-492d0fb75743")
    public Date[] Indisponibilité;

}
