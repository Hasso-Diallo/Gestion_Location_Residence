import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("17f8a389-d4e2-473e-9ff2-a528ab877760")
public class Avis {
    @objid ("8893f81d-afc0-451b-b79e-45cc967fb057")
    protected int Id_Avis;

    @objid ("305fa2ca-8c60-402c-96e0-b80193919c2e")
    public float Note;

    @objid ("0af2979c-24be-43b1-a89c-d4909d336db2")
    public String Commentaire;

}
